This file contains every single used open source components/libraries/dependencies

ICONS

1. weight - https://www.iconfinder.com/icons/3872561/health_medical_weight_management_icon 
http://creativecommons.org/licenses/by/3.0/
https://www.iconfinder.com/Wall_Studio

2. burn - free no attribution required

3. water - https://www.flaticon.com/free-icon/bed_632339#term=sleep&page=1&position=2
https://www.flaticon.com/authors/plainicon

4. sleep - https://www.flaticon.com/free-icon/bed_632339#term=sleep&page=1&position=2
https://www.flaticon.com/authors/cursor-creative

5. heartbeat - https://www.flaticon.com/free-icon/heartbeat_210521#term=heartbeat&page=1&position=3
https://www.flaticon.com/authors/pixel-buddha

6. Plate - https://www.flaticon.com/free-icon/dinner_113227#term=plate&page=1&position=21
https://www.freepik.com/

